var title
var score = 0;
var coin = 0;
var gameState="world1"
var world2=1;

function preload(){
  playerImg=loadAnimation("Images/player.png","Images/hero.png","Images/ritesh.png");
  groundImg=loadImage("Images/ground.png");
 // playerImg2=loadImage("player.2.png");
  obstacleImg=loadImage("Images/obstacle.png");
  groundImg2=loadImage("Images/ground2.png");
fireImg=loadImage("Images/fire.png");
 enemyImg=loadAnimation("Images/enemy.png","Images/mario.png");
 backImg=loadImage("Images/back.png");
 boxImg=loadImage("Images/box.png");
 coinImg=loadImage("Images/coin.png");

}


function setup() {
 createCanvas(1350,650);
  
 back=createSprite(300,300,10,10);
 back.addImage(backImg);
 back.scale=3.6;

 back2=createSprite(3650,300,10,10);
 back2.addImage(backImg);
 back2.scale=3.6;

 back3=createSprite(7100,300,10,10);
 back3.addImage(backImg);
 back3.scale=3.6;

 player=createSprite(250,500,10,10);
 player.addAnimation("runing",playerImg);
 player.scale=0.6;
 
 
ground1 = new Ground(10,620,0.5);
ground2 = new Ground(1400,620,0.5);
ground3 = new Ground(3000,620,0.5);
ground4 = new Ground(3600,620,0.5);
ground5 = new Ground2(2150,320,0.5);
ground6 = new Ground(4600,620,0.5);
ground7 = new Ground(6000,620,0.5);


obstacle1 = new Obstacle(460,480,0.5);
obstacle2 = new Obstacle(1220,480,0.5);
obstacle3 = new Obstacle(2720,480,0.5);
obstacle4 = new Obstacle(3550,480,0.5);
obstacle5 = new Obstacle(4950,480,0.5);

enemy1 = new Enemy(3000,500,0.2);
enemy2 = new Enemy(3200,500,0.2);
enemy3 = new Enemy(4500,500,0.2);
enemy4 = new Enemy(3400,500,0.2);
enemy5 = new Enemy(3800,500,0.2);
enemy6 = new Enemy(3800,500,0.2);
enemy7 = new Enemy(4400,500,0.2);
enemy8 = new Enemy(4200,500,0.2);

box1=new Box(100,200);
box2=new Box(200,200);
box3=new Box(1500,200);
box4=new Box(1600,200);
box5=new Box(1700,200);
box6=new Box(3000,200);
box7=new Box(3100,200);
box8=new Box(3200,200);
box9=new Box(4500,200);
box10=new Box(4000,200);
box11=new Box(4200,200);
box12=new Box(4400,200);
box13=new Box(4100,200);
box14=new Box(4600,200);

title = createElement('h1');




fireGroup = new Group();

}

function draw() {
 background(" lightblue");

 title.html("points :" + score);
  title.position(900, 0);

 

 

if(gameState === "world1"){


 if(keyIsDown(LEFT_ARROW)){
  player.position.x -= 10;
 
  }

  if(keyIsDown(RIGHT_ARROW)){
    player.position.x += 20;
   
   }

  
  if(keyIsDown(DOWN_ARROW)){
     player.position.y += 10;
      }

     

   player.velocityY = player.velocityY + 2.9

   textSize(40);
   fill("red");
  text("player.health = ",player.x-550,60)


   if(player.x>200){
camera.x=player.x;
   }
 


if(fireGroup.isTouching(player)){
  health.width=health.width-50;
  fireGroup.destroyEach();
}







ground1.display();
 ground2.display();
 ground3.display();
 ground4.display();
 ground5.display();
 ground6.display();
 ground7.display();
 
obstacle1.display();
obstacle2.display();
obstacle3.display();
obstacle4.display();
obstacle5.display();

enemy1.display();
enemy2.display();
enemy3.display();
enemy4.display();
enemy5.display();
enemy6.display();
enemy7.display();
enemy8.display();

box1.display();
box2.display();
box3.display();
box4.display();
box5.display();
box6.display();
box7.display();
box8.display();
box9.display();
box10.display();
box11.display();
box12.display();
box13.display();
box14.display();

}


   drawSprites();

}

function keyPressed(){
 // plant1.fire();
}





function obstacles(){
  if(frameCount%20===0){
    obstacle=createSprite(650,480) 
   obstacle.x = obstacle.x ++
    obstacle.addImage(obstacleImg)
   obstacle.scale=0.5
  // obstacle.velocityX=-3;
  
   console.log(obstacle)
    
 // obstacleGroup.add(obstacle)
  
  
  }
}




