class Box{
    constructor(x,y){
        this.body=createSprite(x,y);
        this.body.addImage(boxImg);
        this.body.scale=0.4;

        this.title = createElement('h1');

    }

display(){
    this.title.html("Coin :"+coin);
    this.title.position(500, 0);

player.collide(this.body)


if(player.isTouching(this.body)){
    coin=coin+1;
    this.body.addImage(coinImg);
    this.body.lifetime=4;
    this.body.scale=0.2;
}


}

}