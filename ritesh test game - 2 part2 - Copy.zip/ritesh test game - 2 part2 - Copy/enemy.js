class Enemy{
    constructor(x,y,scale){
        this.body=createSprite(x,y,width,height);
        this.body.addAnimation("runing",enemyImg);
        this.body.scale=scale;
        this.body.velocityX=(random(4,-4))

        this.ground=createSprite(x,y,100,10);
        this.ground.y=590;
        this.ground.visible=false;

        this.head=createSprite(x,y,50,10);
        this.head.visible=false;

        this.obstacle1=createSprite(2760,480,20,200);
        this.obstacle2=createSprite(3550,480,100,200);
        this.obstacle3=createSprite(4950,480,100,200);



            }
        
        display(){
        this.ground.x=this.body.x;
      
        this.head.x=this.body.x;
        this.head.y=this.body.y-40;

        if (player.isTouching(this.head) && player.y < this.head.y + 0) {
            this.body.destroy();
            score=score+100
          }

         if( player.isTouching(this.body)){
             player.x=400;
             player.y=500;
         }


         this.obstacle1.visible=false;
         this.obstacle2.visible=false;
         this.obstacle3.visible=false;

              this.body.collide(this.ground);
              this.body.velocityY=1;
          
            
              this.body.bounceOff(this.obstacle1);
              this.body.bounceOff(this.obstacle2);
              this.body.bounceOff(this.obstacle3);
        
        }


}